# Comic Book Day for iPhone, never miss a release of your favorite heroes

Lyon, France — February 7, 2014 — Studio AMANgA today released Comic Book Day for iPhone and iPod touch. Comic Book Day keeps track of the comic books you love. Simply manage your library, and receive a notification every time a new issue hits the stores.

## Comic Book Day Features

- Import volumes directly from a database of more than 380,000 comic books, manga, and other international publications.
- Organize the comic books you’ve already read, and know what to read next.
- Share your favorite issues with your friends, and discover new books to love.

## Pricing and Availability

Comic Book Day is available on the App Store for free. Comic Book Day is designed for iPhone and iPod touch. Comic Book Day requires iOS 7.0 or newer.

App Store Link: https://itunes.apple.com/app/comic-book-day/id788312005

## About Studio AMANgA

Studio AMANgA is an independent developer based in Lyon, France.

You can find out more at http://www.studioamanga.com

## Press Contact

Email: studioamanga@gmail.com
Twitter: @StudioAMANgA
Website: http://www.studioamanga.com/comicbookday